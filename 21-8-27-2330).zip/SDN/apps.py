from django.apps import AppConfig


class SdnConfig(AppConfig):
    name = 'SDN'
