from django.apps import AppConfig


class DeviceinformationConfig(AppConfig):
    name = 'DeviceInformation'
