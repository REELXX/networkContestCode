from django.apps import AppConfig


class UserinformationConfig(AppConfig):
    name = 'UserInformation'
