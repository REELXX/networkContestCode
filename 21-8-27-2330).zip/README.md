# 21Ynetcontest
2021年计算机网络大赛的代码简介

DeviceInformation：查询用户列表{unix时间戳——北京时间} ;AP信息提取 ;用户趋势;

Home：注册登录注销;个人信息主页（查询，修改） ;语音模块/语音识别/语音跳转;邮箱告警

SDN：智能评估体系;svm算法;热力图

环境：python--3.6 + requirements包
